﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oneinstanceapplication
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            if (processnumber() == 1)
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());
            }
            else
            {
                MessageBox.Show("application is already running");
                Application.Exit();
            }
        }
        public static int  processnumber()
        {
            int i = 0;
            Process process = Process.GetCurrentProcess();
            Process[] procs = Process.GetProcessesByName(process.ProcessName);
            foreach(Process pro in procs) {
                if((pro.Id!=process.Id)&& (process.MainModule.FileName==pro.MainModule.FileName)) {
                i++;}
            }
            return i + 1;
        }
    }
}
